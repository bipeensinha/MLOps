from flask import Flask, render_template, request, jsonify
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

app = Flask(__name__)

data = pd.read_csv("transactions.csv")
transactions = data["Products"].apply(lambda x: [p.strip() for p in x.split(",")]).tolist()

encoder = TransactionEncoder()
basket = pd.DataFrame(
    encoder.fit(transactions).transform(transactions),
    columns=encoder.columns_
)

frequent_items = apriori(basket, min_support=0.20, use_colnames=True)
rules = association_rules(frequent_items, metric="confidence", min_threshold=0.40)

PRODUCTS = sorted({p for t in transactions for p in t})
PRODUCT_INFO = {
    "Laptop": {"price": 750, "emoji": "💻"},
    "Mouse": {"price": 25, "emoji": "🖱️"},
    "Laptop Bag": {"price": 35, "emoji": "💼"},
    "Keyboard": {"price": 45, "emoji": "⌨️"},
    "Phone": {"price": 450, "emoji": "📱"},
    "Phone Case": {"price": 15, "emoji": "📱"},
    "Screen Guard": {"price": 10, "emoji": "🛡️"},
    "Earphones": {"price": 20, "emoji": "🎧"},
}

def get_recommendations(products):
    selected = set(products)
    scores = {}
    for _, rule in rules.iterrows():
        if set(rule["antecedents"]).intersection(selected):
            for item in set(rule["consequents"]):
                if item not in selected:
                    scores[item] = max(scores.get(item, 0), float(rule["confidence"]))
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:4]
    return [
        {
            "product": item,
            "confidence": round(conf * 100),
            "price": PRODUCT_INFO.get(item, {"price": 0})["price"],
            "emoji": PRODUCT_INFO.get(item, {"emoji": "🛍️"})["emoji"]
        }
        for item, conf in ranked
    ]

@app.route("/")
def home():
    return render_template("index.html", products=PRODUCTS, product_info=PRODUCT_INFO)

@app.route("/recommend", methods=["POST"])
def recommend():
    payload = request.get_json(silent=True) or {}
    products = payload.get("products", [])
    return jsonify({"selected": products, "recommendations": get_recommendations(products)})

if __name__ == "__main__":
    app.run(debug=True)
