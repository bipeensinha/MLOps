let cart = [];
let selectedProducts = [];

const prices = {
  "Laptop": 750,
  "Mouse": 25,
  "Laptop Bag": 35,
  "Keyboard": 45,
  "Phone": 450,
  "Phone Case": 15,
  "Screen Guard": 10,
  "Earphones": 20
};

const emojis = {
  "Laptop": "💻",
  "Mouse": "🖱️",
  "Laptop Bag": "💼",
  "Keyboard": "⌨️",
  "Phone": "📱",
  "Phone Case": "📱",
  "Screen Guard": "🛡️",
  "Earphones": "🎧"
};

function selectProduct(product) {
  cart.push(product);

  if (!selectedProducts.includes(product)) {
    selectedProducts.push(product);
  }

  updateCart();
  updateRecommendations();
}

async function updateRecommendations() {
  document.getElementById("selectedText").textContent =
    `${selectedProducts.length} selected`;

  const container = document.getElementById("recommendations");

  if (!selectedProducts.length) {
    container.innerHTML =
      '<div class="empty-state">Add a product to see AI-powered recommendations.</div>';
    return;
  }

  try {
    const response = await fetch("/recommend", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({products: selectedProducts})
    });

    if (!response.ok) throw new Error("Recommendation API failed");

    const data = await response.json();

    if (!data.recommendations.length) {
      container.innerHTML =
        '<div class="empty-state">No strong association found for the selected products.</div>';
      return;
    }

    container.innerHTML = data.recommendations.map(item => `
      <div class="recommendation-card">
        <div class="rec-icon">${item.emoji}</div>
        <h3>${item.product}</h3>
        <div class="price">$${Number(item.price).toFixed(2)}</div>
        <div class="confidence">
          Association confidence: ${item.confidence}%
        </div>
        <div class="confidence-bar">
          <span style="width:${Math.min(item.confidence, 100)}%"></span>
        </div>
        <br>
        <button class="add-btn"
          onclick="selectProduct('${item.product}')">
          Add to Cart
        </button>
      </div>
    `).join("");
  } catch (error) {
    container.innerHTML =
      '<div class="empty-state">Unable to contact the Python recommendation service.</div>';
  }
}

function updateCart() {
  document.getElementById("cartCount").textContent = cart.length;

  const container = document.getElementById("cartItems");

  if (!cart.length) {
    container.innerHTML = "<p>Your cart is empty.</p>";
    document.getElementById("subtotal").textContent = "$0.00";
    return;
  }

  const counts = {};
  cart.forEach(p => counts[p] = (counts[p] || 0) + 1);

  let subtotal = 0;

  container.innerHTML = Object.entries(counts).map(([product, qty]) => {
    subtotal += (prices[product] || 0) * qty;

    return `
      <div class="cart-line">
        <span class="icon">${emojis[product] || "🛍️"}</span>
        <div>
          <strong>${product}</strong><br>
          <small>$${(prices[product] || 0).toFixed(2)} × ${qty}</small>
        </div>
        <button class="remove-btn" onclick="removeFromCart('${product}')">
          −
        </button>
      </div>
    `;
  }).join("");

  document.getElementById("subtotal").textContent =
    `$${subtotal.toFixed(2)}`;
}

function removeFromCart(product) {
  const index = cart.lastIndexOf(product);

  if (index !== -1) {
    cart.splice(index, 1);
  }

  if (!cart.includes(product)) {
    selectedProducts = selectedProducts.filter(p => p !== product);
  }

  updateCart();
  updateRecommendations();
}

function toggleCart() {
  document.getElementById("cartDrawer").classList.toggle("open");
  document.getElementById("overlay").classList.toggle("show");
}

function checkout() {
  if (!cart.length) {
    alert("Your cart is empty. Add a product before checkout.");
    return;
  }

  alert(
    "Demo checkout successful!\\n\\n" +
    "This is a training demo — no real payment is processed."
  );
}

function goHome(event) {
  event.preventDefault();
  window.scrollTo({top: 0, behavior: "smooth"});
}

function startShopping(event) {
  event.preventDefault();
  document.getElementById("products").scrollIntoView({behavior: "smooth"});
}

function showAllProducts(event) {
  event.preventDefault();
  document.getElementById("searchBox").value = "";
  document.querySelectorAll(".product-card").forEach(card => {
    card.style.display = "";
  });
  document.getElementById("products").scrollIntoView({behavior: "smooth"});
}

function filterCategory(category) {
  const mapping = {
    Electronics: ["Laptop", "Phone", "Keyboard", "Mouse", "Earphones"],
    Mobiles: ["Phone", "Phone Case", "Screen Guard", "Earphones"],
    Computers: ["Laptop", "Mouse", "Keyboard", "Laptop Bag"],
    Accessories: ["Mouse", "Keyboard", "Phone Case", "Screen Guard", "Earphones"],
    Audio: ["Earphones"],
    Bags: ["Laptop Bag"],
    Peripherals: ["Mouse", "Keyboard"]
  };

  const allowed = mapping[category] || [];

  document.getElementById("searchBox").value = "";

  document.querySelectorAll(".product-card").forEach(card => {
    card.style.display =
      allowed.includes(card.dataset.product) ? "" : "none";
  });

  document.getElementById("products").scrollIntoView({behavior: "smooth"});
}

document.getElementById("cartButton").addEventListener("click", toggleCart);

document.getElementById("searchBox").addEventListener("input", function() {
  const q = this.value.toLowerCase();

  document.querySelectorAll(".product-card").forEach(card => {
    card.style.display =
      card.dataset.product.toLowerCase().includes(q) ? "" : "none";
  });
});

updateCart();
updateRecommendations();
